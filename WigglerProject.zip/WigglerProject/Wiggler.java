class Wiggler
{
  private int myX, myY;
  public int getNum(){
    return (int) myNum;
  }
  public void setNum (int nNew_){
    myNum= nNew_;
  }
  Wiggler()
  {
    myX = myY = 150;
  }
  void wiggle()
  {
    myX+=(int)(Math.random()*5)-2;
  }
}
